import Employee from '../models/Employee.js';

// Create Employee
export const createEmployee = async (req, res) => {
  const { f_Name, f_Email, f_Mobile, f_Designation, f_gender, f_Course } = req.body;
  const f_Image = req.file ? req.file.path : '';
  console.log('req.body', req.body);
  
  try {
    const newEmployee = new Employee({ f_Image, f_Name, f_Email, f_Mobile, f_Designation, f_gender, f_Course });
    await newEmployee.save();
    res.json({ success: true, employee: newEmployee });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Get Employees
export const getEmployees = async (req, res) => {
  try {
    const employees = await Employee.find();
    const count = await Employee.countDocuments();
    res.json({ success: true, employees, count });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Update Employee
export const updateEmployee = async (req, res) => {
  const { id } = req.params;
  const updatedData = req.body;
  if (req.file) {
    updatedData.f_Image = req.file.path;
  }

  try {
    const updatedEmployee = await Employee.findByIdAndUpdate(id, updatedData, { new: true });
    if (!updatedEmployee) {
      return res.status(404).json({ success: false, message: 'Employee not found' });
    }
    res.json({ success: true, employee: updatedEmployee });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Delete Employee
export const deleteEmployee = async (req, res) => {
  const { id } = req.params;

  try {
    const deletedEmployee = await Employee.findByIdAndDelete(id);
    if (!deletedEmployee) {
      return res.status(404).json({ success: false, message: 'Employee not found' });
    }
    res.json({ success: true, message: 'Employee deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};
export const getEmployeeById = async (req, res) => {
  const { id } = req.params;

  try {
    const employee = await Employee.findById(id);
    if (!employee) {
      return res.status(404).json({ success: false, message: 'Employee not found' });
    }
    res.json({ success: true, employee });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};