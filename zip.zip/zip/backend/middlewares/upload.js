import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Define the directory for uploads
const uploadDir = 'uploads/';

// Ensure the upload directory exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
  console.log(`Directory created: ${uploadDir}`);
} else {
  console.log(`Directory already exists: ${uploadDir}`);
}

// Define storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    console.log(`Upload destination: ${uploadDir}`); // Log the upload directory path
    cb(null, uploadDir); // Use the directory path
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext); // Add timestamp to avoid file name conflicts
  },
});

// Define file filter to accept only JPG and PNG
const fileFilter = (req, file, cb) => {
  const filetypes = /jpeg|jpg|png/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = filetypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  }
  cb(new Error('Invalid file type. Only JPG and PNG files are allowed.'));
};

// Initialize multer with storage and file filter
const upload = multer({ storage, fileFilter });

export default upload;
