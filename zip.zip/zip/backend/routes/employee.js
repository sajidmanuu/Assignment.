// routes/employee.js
import express from 'express';
import { getEmployeeById,createEmployee, getEmployees, updateEmployee, deleteEmployee } from '../controllers/employeeController.js';
import upload from '../middlewares/upload.js';

const router = express.Router();

// Route to create a new employee (with file upload)
router.post('/employees', upload.single('f_Image'), createEmployee);

// Route to get all employees (no file upload needed here)
router.get('/employees', getEmployees);
router.get('/employees/:id', getEmployeeById)
// Route to update an employee by ID (with file upload if needed)
router.put('/employees/:id', upload.single('f_Image'), updateEmployee);

// Route to delete an employee by ID
router.delete('/employees/:id', deleteEmployee);

export default router;
