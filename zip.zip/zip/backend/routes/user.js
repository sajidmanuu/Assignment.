import express from 'express';
import { login, register } from '../controllers/authController.js';
// import { createEmployee, getEmployees } from '../controllers/employeeController.js';

const router = express.Router();

// Auth routes
router.post('/login', login);
router.post('/register', register);


export default router;
