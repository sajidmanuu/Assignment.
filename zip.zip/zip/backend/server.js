import express from 'express';
import connectDB from './config/db.js';
import userRoutes from './routes/user.js';
import employeeRoutes from './routes/employee.js';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 5000;

// Get the current directory path in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

connectDB();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/user', userRoutes);
app.use('/api/employee', employeeRoutes);

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
