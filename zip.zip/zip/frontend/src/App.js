import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import './App.css';
import CreateEmployee from './components/createEmployee';
import Employelist from './Pages/Employelist';
import EditEmployee from './Pages/EditEmployee';
import Home from './Pages/Home';

const App = () => {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <Router>
      <div className="App">
        <Routes>

          <Route path="/login" element={<LoginPage />} />

          <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/login" />} />
          <Route path="/" element={user ? <Home /> : <Navigate to="/login" />} />
          <Route path="/create-emp" element={user ? <CreateEmployee /> : <Navigate to="/login" />} />
          <Route path="/emp-list" element={user ? <Employelist /> : <Navigate to="/login" />} />
          <Route path="/edit-emp/:id" element={user ? <EditEmployee /> : <Navigate to="/login" />} />        <Route path="/edit-emp/:id" element={<EditEmployee />} />
          {/* <Route path="/edit-emp/:id" element={<EditEmployee />} /> */}

        </Routes>
      </div>
    </Router>
  );
};

export default App;
