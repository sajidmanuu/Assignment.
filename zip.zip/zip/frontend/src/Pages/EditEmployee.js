import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import Layout from './Layout';
import '../css/editEmployee.css';
const EditEmployee = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    f_Name: '',
    f_Email: '',
    f_Mobile: '',
    f_Designation: '',
    f_gender: '',
    f_Course: '',
    f_Image: ''
  });

  useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/employee/employees/${id}`);
        setEmployee(response.data.employee);
        setFormData(response.data.employee);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching employee data:', error);
        setLoading(false);
      }
    };

    fetchEmployee();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, f_Image: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formDataToSend = new FormData();
    for (const key in formData) {
      formDataToSend.append(key, formData[key]);
    }

    try {
      await axios.put(`http://localhost:5000/api/employee/employees/${id}`, formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      navigate('/emp-list');
    } catch (error) {
      console.error('Error updating employee data:', error);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <Layout>
      <div className='edit-container'><h2>Edit Employee</h2>
        <div className='edit-form'>
          <form onSubmit={handleSubmit}>
            <div class>
              <label>Name:</label>
              <input type="text" name="f_Name" value={formData.f_Name} onChange={handleChange} />
            </div>
            <div>
              <label>Email:</label>
              <input type="email" name="f_Email" value={formData.f_Email} onChange={handleChange} />
            </div>
            <div>
              <label>Mobile:</label>
              <input type="text" name="f_Mobile" value={formData.f_Mobile} onChange={handleChange} />
            </div>
            <div>
              <label>Designation:</label>
              <input type="text" name="f_Designation" value={formData.f_Designation} onChange={handleChange} />
            </div>
            <div>
              <label>Gender:</label>
              <input type="text" name="f_gender" value={formData.f_gender} onChange={handleChange} />
            </div>
            <div>
              <label>Course:</label>
              <input type="text" name="f_Course" value={formData.f_Course} onChange={handleChange} />
            </div>
            <div>
              <input type="file" name="f_Image" onChange={handleFileChange} />
              <label>Image:</label>
              {formData.f_Image && (

                <img
                  src={`http://localhost:5000/${formData.f_Image}`}
                  alt="Current"
                  style={{ width: '100px', height: '100px', display: 'block', marginBottom: '10px' }}
                />

              )}

            </div>

          </form>
          <div>
            <button onClick={handleSubmit} className='edit-submit' type="submit">Update</button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default EditEmployee;
