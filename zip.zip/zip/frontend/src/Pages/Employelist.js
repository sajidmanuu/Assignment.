import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Layout from './Layout';
import '../css/EmployeeList.css';

const EmployeeList = () => {
  const navigate = useNavigate();

  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/employee/employees');
        setEmployees(response.data.employees);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching employee data:', error);
        setLoading(false);
      }
    };

    fetchEmployees();
  }, []);

  const handleClick = () => {
    navigate('/create-emp');
  };

  const handleEdit = (id) => {
    navigate(`/edit-emp/${id}`);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/employee/employees/${id}`);
      setEmployees(employees.filter(employee => employee._id !== id));
    } catch (error) {
      console.error('Error deleting employee:', error);
    }
  };

  const filteredEmployees = employees.filter(employee =>
    employee.f_Name.toLowerCase().includes(search.toLowerCase()) ||
    employee.f_Email.toLowerCase().includes(search.toLowerCase()) ||
    employee._id.includes(search) ||
    new Date(employee.f_Createdate).toLocaleDateString().includes(search)
  );

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <Layout>
      <div className='emp-container'>
        <h1 className='title'>Employee List</h1>
        <div className='container'>
          <h5 className='emp-count'>Total count: {filteredEmployees.length}</h5>
          <button className='emp-button' onClick={handleClick}>Create Employee</button>
        </div>

        <div className='emp-search'>
          <h3 className='search'>Search</h3>
          <input
            placeholder="Search by Name, Email, ID, or Date"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <table className='employee-list-container'>
          <thead>
            <tr>
              <th>S.N</th>
              <th>Image</th>
              <th>Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Designation</th>
              <th>Gender</th>
              <th>Course</th>
              <th>Create Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredEmployees.map((employee, index) => (
              <tr key={employee._id}>
                <td>{index + 1}</td>
                <td><img src={`http://localhost:5000/${employee.f_Image}`} alt={employee.f_Name} style={{ width: '50px', height: '50px' }} /></td>
                <td>{employee.f_Name}</td>
                <td>{employee.f_Email}</td>
                <td>{employee.f_Mobile}</td>
                <td>{employee.f_Designation}</td>
                <td>{employee.f_gender}</td>
                <td>{employee.f_Course}</td>
                <td>{new Date(employee.f_Createdate).toLocaleDateString()}</td>
                <td>
                  <div className='action-buttons'>
                    <div className='button'>
                      <div className='edit-button'>
                        <button onClick={() => handleEdit(employee._id)}>Edit</button>
                      </div>
                      <div className='delete-button'>
                        <button onClick={() => handleDelete(employee._id)}>Delete</button>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
};

export default EmployeeList;
