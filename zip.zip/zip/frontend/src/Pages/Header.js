import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../css/header.css';

const Header = () => {
  const navigate = useNavigate(); // Hook to programmatically navigate
  const username = localStorage.getItem('username');

  const logoutButton = () => {
    localStorage.clear();
    navigate('/'); // Navigate to the home page after logout
  };

  // Clean up the username string if necessary
  const cleanedUsername = username ? username.replace(/^"|"$/g, '') : 'Guest'; // Remove quotes if they exist

  return (
    <div className='header'>
      <div className='pages'>
        <Link to="/" className='link'>Home</Link>
        <Link to="/emp-list" className='link'>Employee List</Link>
      </div>
      <h3 className='user'>{cleanedUsername}</h3>
      {cleanedUsername !== 'Guest' ? (
        <button onClick={logoutButton} className='user-button'>Log Out</button>
      ) : (
        <Link to="/login" className='user-button' >Login</Link>
      )}
    </div>
  );
};

export default Header;
