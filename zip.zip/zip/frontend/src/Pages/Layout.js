import React from 'react'
import Home from './Home'
// import Employee from '../../../../server/models/Employee'
import Header from './Header'
import CreateEmployee from '../components/createEmployee'
import Employelist from './Employelist'
import '../css/layout.css';
const Layout = ({ children }) => {
  return (
    <div className='app'>
      <div className='logo'>Logo</div>

      <Header />
      {/* <Employelo/> */}
      {children}

      {/* Other components and content */}

    </div>
  )
}

export default Layout