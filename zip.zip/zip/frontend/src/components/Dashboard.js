import React from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../Pages/Layout';

const Dashboard = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'));

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <Layout>
     <h1>Admin Dashboard</h1>
    </Layout>
  );
};

export default Dashboard;
