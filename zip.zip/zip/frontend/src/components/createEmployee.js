import React, { useState } from 'react';
import { Form, Input, Button, Upload, message, Select, Radio, Checkbox } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import axios from 'axios';
import Layout from '../Pages/Layout';
// import './CreateEmployee.css'
// import CreateEmployee from './createEmployee';
const { Option } = Select;

const CreateEmployee = () => {
  const [form] = Form.useForm();
  const [fileList, setFileList] = useState([]);

  const handleSubmit = async (values) => {
    const formData = new FormData();
    formData.append('f_Name', values.f_Name);
    formData.append('f_Email', values.f_Email);
    formData.append('f_Mobile', values.f_Mobile);
    formData.append('f_Designation', values.f_Designation);
    formData.append('f_gender', values.f_gender);
    formData.append('f_Course', values.f_Course.join(', ')); // Join checkbox values with a comma

    if (fileList.length > 0) {
      formData.append('f_Image', fileList[0].originFileObj);
    }

    try {
      const response = await axios.post('http://localhost:5000/api/employee/employees', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      message.success('Employee created successfully!');
      form.resetFields();
      setFileList([]);
    } catch (error) {
      message.error('Error creating employee.');
      console.error('Error:', error.response.data);
    }
  };

  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

  return (
    <Layout>
      <div style={{ padding: '20px' }}>
        <Form form={form} onFinish={handleSubmit} layout="vertical">
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <Form.Item
              name="f_Name"
              label="Name"
              style={{ width: '48%' }}
              rules={[{ required: true, message: 'Please enter the name!' }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="f_Email"
              label="Email"
              style={{ width: '48%' }}
              rules={[{ required: true, message: 'Please enter the email!' }, { type: 'email', message: 'Please enter a valid email!' }]}
            >
              <Input />
            </Form.Item>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <Form.Item
              name="f_Mobile"
              label="Mobile"
              style={{ width: '48%' }}
              rules={[{ required: true, message: 'Please enter the mobile number!' }, { pattern: /^[0-9]+$/, message: 'Mobile number must be numeric!' }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="f_Designation"
              label="Designation"
              style={{ width: '48%' }}
              rules={[{ required: true, message: 'Please enter the designation!' }]}
            >
              <Select placeholder="Select a role">
                <Option value="HR">HR</Option>
                <Option value="Manager">Manager</Option>
                <Option value="Sales">Sales</Option>
              </Select>
            </Form.Item>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <Form.Item
              name="f_gender"
              label="Gender"
              style={{ width: '48%' }}
              rules={[{ required: true, message: 'Please select the gender!' }]}
            >
              <Radio.Group>
                <Radio value="M">Male</Radio>
                <Radio value="F">Female</Radio>
              </Radio.Group>
            </Form.Item>
            <Form.Item
              name="f_Course"
              label="Course"
              style={{ width: '48%' }}
              rules={[{ required: true, message: 'Please select at least one course!' }]}
            >
              <Checkbox.Group>
                <Checkbox value="MCA">MCA</Checkbox>
                <Checkbox value="BCA">BCA</Checkbox>
                <Checkbox value="BSC">BSC</Checkbox>
              </Checkbox.Group>
            </Form.Item>
          </div>
          <Form.Item
            name="f_image"
            label="Upload Image"
            rules={[{ required: true, message: 'Please upload an image!' }]}
          >
            <Upload
              listType="picture"
              fileList={fileList}
              onChange={handleChange}
              beforeUpload={(file) => {
                const isImage = file.type === 'image/jpeg' || file.type === 'image/png';
                if (!isImage) {
                  message.error('You can only upload JPG/PNG file!');
                }
                return isImage;
              }}
            >
              <Button icon={<UploadOutlined />}>Select File</Button>
            </Upload>
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">Create Employee</Button>
          </Form.Item>
        </Form>
      </div>
    </Layout>
  );
};

export default CreateEmployee;
